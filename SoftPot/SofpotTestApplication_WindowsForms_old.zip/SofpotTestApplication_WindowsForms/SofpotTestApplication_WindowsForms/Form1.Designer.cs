﻿namespace SofpotTestApplication_WindowsForms
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.happy = new System.Windows.Forms.Panel();
            this.sad = new System.Windows.Forms.Panel();
            this.angry = new System.Windows.Forms.Panel();
            this.normal3 = new System.Windows.Forms.Panel();
            this.normal2 = new System.Windows.Forms.Panel();
            this.normal1 = new System.Windows.Forms.Panel();
            this.normal4 = new System.Windows.Forms.Panel();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.happy.SuspendLayout();
            this.sad.SuspendLayout();
            this.angry.SuspendLayout();
            this.normal3.SuspendLayout();
            this.normal2.SuspendLayout();
            this.normal1.SuspendLayout();
            this.normal4.SuspendLayout();
            this.SuspendLayout();
            // 
            // happy
            // 
            this.happy.Controls.Add(this.label1);
            this.happy.Location = new System.Drawing.Point(0, 0);
            this.happy.Name = "happy";
            this.happy.Size = new System.Drawing.Size(129, 124);
            this.happy.TabIndex = 0;
            // 
            // sad
            // 
            this.sad.Controls.Add(this.label2);
            this.sad.Location = new System.Drawing.Point(147, 0);
            this.sad.Name = "sad";
            this.sad.Size = new System.Drawing.Size(129, 124);
            this.sad.TabIndex = 1;
            // 
            // angry
            // 
            this.angry.Controls.Add(this.label3);
            this.angry.Location = new System.Drawing.Point(292, 0);
            this.angry.Name = "angry";
            this.angry.Size = new System.Drawing.Size(129, 124);
            this.angry.TabIndex = 2;
            // 
            // normal3
            // 
            this.normal3.Controls.Add(this.label6);
            this.normal3.Location = new System.Drawing.Point(292, 143);
            this.normal3.Name = "normal3";
            this.normal3.Size = new System.Drawing.Size(129, 124);
            this.normal3.TabIndex = 5;
            // 
            // normal2
            // 
            this.normal2.Controls.Add(this.label5);
            this.normal2.Location = new System.Drawing.Point(147, 143);
            this.normal2.Name = "normal2";
            this.normal2.Size = new System.Drawing.Size(129, 124);
            this.normal2.TabIndex = 4;
            // 
            // normal1
            // 
            this.normal1.Controls.Add(this.label4);
            this.normal1.Location = new System.Drawing.Point(0, 143);
            this.normal1.Name = "normal1";
            this.normal1.Size = new System.Drawing.Size(129, 124);
            this.normal1.TabIndex = 3;
            // 
            // normal4
            // 
            this.normal4.Controls.Add(this.label7);
            this.normal4.Location = new System.Drawing.Point(438, 143);
            this.normal4.Name = "normal4";
            this.normal4.Size = new System.Drawing.Size(129, 124);
            this.normal4.TabIndex = 6;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(438, 0);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(129, 121);
            this.listBox1.TabIndex = 7;
            // 
            // timer2
            // 
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(43, 56);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(43, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "HAPPY";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(44, 56);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(29, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "SAD";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(33, 56);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(45, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "ANGRY";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(24, 63);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(62, 13);
            this.label4.TabIndex = 1;
            this.label4.Text = "NORMAL 1";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(33, 63);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(62, 13);
            this.label5.TabIndex = 2;
            this.label5.Text = "NORMAL 2";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(33, 63);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(62, 13);
            this.label6.TabIndex = 3;
            this.label6.Text = "NORMAL 3";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(35, 63);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(62, 13);
            this.label7.TabIndex = 4;
            this.label7.Text = "NORMAL 4";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(568, 268);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.normal4);
            this.Controls.Add(this.normal3);
            this.Controls.Add(this.angry);
            this.Controls.Add(this.normal2);
            this.Controls.Add(this.normal1);
            this.Controls.Add(this.sad);
            this.Controls.Add(this.happy);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load_1);
            this.happy.ResumeLayout(false);
            this.happy.PerformLayout();
            this.sad.ResumeLayout(false);
            this.sad.PerformLayout();
            this.angry.ResumeLayout(false);
            this.angry.PerformLayout();
            this.normal3.ResumeLayout(false);
            this.normal3.PerformLayout();
            this.normal2.ResumeLayout(false);
            this.normal2.PerformLayout();
            this.normal1.ResumeLayout(false);
            this.normal1.PerformLayout();
            this.normal4.ResumeLayout(false);
            this.normal4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel happy;
        private System.Windows.Forms.Panel sad;
        private System.Windows.Forms.Panel angry;
        private System.Windows.Forms.Panel normal3;
        private System.Windows.Forms.Panel normal2;
        private System.Windows.Forms.Panel normal1;
        private System.Windows.Forms.Panel normal4;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label7;
    }
}

