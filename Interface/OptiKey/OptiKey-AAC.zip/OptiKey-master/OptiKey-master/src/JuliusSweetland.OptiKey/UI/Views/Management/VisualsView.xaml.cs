using System.Windows.Controls;

namespace JuliusSweetland.OptiKey.UI.Views.Management
{
    /// <summary>
    /// Interaction logic for VisualsView.xaml
    /// </summary>
    public partial class VisualsView : UserControl
    {
        public VisualsView()
        {
            InitializeComponent();
        }
    }
}
