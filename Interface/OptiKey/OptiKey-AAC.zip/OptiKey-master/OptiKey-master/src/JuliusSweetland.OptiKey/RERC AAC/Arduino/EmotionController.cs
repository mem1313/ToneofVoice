﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Speech.Synthesis;
using JuliusSweetland.OptiKey.RERC_AAC.Enums;

namespace JuliusSweetland.OptiKey.RERC_AAC.Arduino
{
    class EmotionController
    {
        #region Fields
        private SpeechSynthesizer voice;
        private PromptBuilder strBuilder;
        #endregion

        #region Methods
        public EmotionController()
        {
            voice = new SpeechSynthesizer();
            strBuilder = new PromptBuilder();


            //string happy = "<prosody pitch=\"x-high\" rate=\"medium\" volume=\"x-loud\"> This is high pitch, medium speaking rate and loud volume. </prosody >";
            //string normal = "<prosody pitch=\"low\" rate=\"medium\" volume=\"loud\"> This is low pitch, medium speaking rate and loud volume. </prosody >";
            //string sad = "<prosody pitch=\"x-low\" range=\"15Hz\" rate=\"slow\" volume=\"soft\"> I am not feelling good right now. </prosody >";

            //pb1.AppendSsmlMarkup(happy);
            //pb1.AppendSsmlMarkup(normal);
            //pb1.AppendSsmlMarkup(sad);

            //voice.SpeakAsync(pb1);
        }

        public void SpeakWithEmotion(string sentenceToSpeak)
        {
            EmotionList selectedEmotion;
            string textToSpeak = string.Empty;

            if (!Enum.TryParse(DataHandler.Emotion, true, out selectedEmotion))
            {
                selectedEmotion = EmotionList.normal;
            }

            switch (selectedEmotion)
            {
                case EmotionList.happy:
                    {
                        textToSpeak = "<prosody pitch=\"x-high\" rate=\"medium\" volume=\"x-loud\"> " + sentenceToSpeak + " </prosody >";
                        break;
                    }
                case EmotionList.sad:
                    {
                        textToSpeak = "<prosody pitch=\"x-low\" range=\"15Hz\" rate=\"slow\" volume=\"soft\"> " + sentenceToSpeak + " </prosody >";
                        break;
                    }
                case EmotionList.angry:
                    {
                        textToSpeak = "<prosody pitch=\"low\" rate=\"medium\" volume=\"loud\"> " + sentenceToSpeak + " </prosody >";
                        break;
                    }
                case EmotionList.irritated:
                    {
                        textToSpeak = "<prosody pitch=\"low\" rate=\"medium\" volume=\"loud\"> " + sentenceToSpeak + " </prosody >";
                        break;
                    }
                case EmotionList.normal:
                    {
                        textToSpeak = "<prosody pitch=\"low\" rate=\"medium\" volume=\"loud\"> " + sentenceToSpeak + " </prosody >";
                        break;
                    }
                default:
                    {
                        textToSpeak = "<prosody pitch=\"low\" rate=\"medium\" volume=\"loud\"> " + sentenceToSpeak + " </prosody >";
                        break;
                    }
            }

            strBuilder.ClearContent();
            strBuilder.AppendSsmlMarkup(textToSpeak);
            voice.SpeakAsync(strBuilder);

        }

        #endregion
    }
}
