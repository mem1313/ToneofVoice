﻿using System;
using System.IO.Ports;
using System.Threading;
using System.Speech.Synthesis;
using JuliusSweetland.OptiKey.RERC_AAC.Enums;
using JuliusSweetland.OptiKey.RERC_AAC.Windows;
using JuliusSweetland.OptiKey.UI.Windows;
using System.Management;
using System.Windows;
using System.Collections.Generic;
using System.ComponentModel;

namespace JuliusSweetland.OptiKey.RERC_AAC.Arduino
{
    class DataHandler
    {

        #region Fields
        static private SerialPort myPort;
        private string incomingMessage;
        private SpeechSynthesizer speech;
        private string currentEmotion;
        private static string cEmotion;
        delegate void setArduinoMessage(string text);

        public Thread getPortThread;
        public Thread notificationThread;
        private string portName1 = "";
        SerialPort sp;
        string[] availablePorts;
        BackgroundWorker back;
        string arduinoPort = "";

        List<string> portList = new List<string>();
        private PopupNotification notification;
        private bool emotionChanged;

        public int count;
        #endregion

        #region Properties
        public static string Emotion
        {
            get { return cEmotion; }
            //set { cEmotion = value; }
        }

        #endregion

        #region Methods


        public DataHandler()
        {
            myPort = new SerialPort();
            currentEmotion = string.Empty;
            cEmotion = string.Empty;
            emotionChanged = false;
            getPortThread = null;

            this.getPortThread = new Thread(new ThreadStart(this.GetComPort));
            this.getPortThread.Start();

            EstablishThread();
            

            back = new BackgroundWorker();
            back.DoWork += new DoWorkEventHandler(BackgroundWorker_DoWork);
            back.RunWorkerAsync();

            count = 0;

            //arduinoMessageThread = new Thread(new ThreadStart(this.MessageFromArduino));
            //arduinoMessageThread.SetApartmentState(ApartmentState.STA);
            //arduinoMessageThread.Start();

            //MessageFromArduino();
        }

        private void EstablishThread() 
        {
            this.notificationThread = new Thread(new ThreadStart(this.ThreadNotify));
            this.notificationThread.SetApartmentState(ApartmentState.STA);
            this.notificationThread.Start();
        }

        private void MessageFromArduino()
        {
            //notification = new PopupNotification();
            
            /*myPort.PortName = "COM5";
            myPort.BaudRate = 9600;
            myPort.Parity = Parity.None;
            myPort.StopBits = StopBits.One;
            myPort.DataBits = 8;
            myPort.Handshake = Handshake.None;
            myPort.RtsEnable = true; */

            sp.BaudRate = 9600;
            sp.Parity = Parity.None;
            sp.StopBits = StopBits.One;
            sp.DataBits = 8;
            sp.Handshake = Handshake.None;
            sp.RtsEnable = true;

            // using an event instead of a thread
            // this is for testing purposes and it works 
            //myPort.DataReceived += new SerialDataReceivedEventHandler(DataReceivedHandler);

            //myPort.Open();

            //while (myPort.IsOpen)
            //{
            //    cEmotion = SelectedEmotion();

            //    if(emotionChanged)
            //    {
            //        notification.EmotionText.Text = cEmotion;
            //        notification.Show();
            //        emotionChanged = false;
            //    }
                
            //}

            while(true)
            {
                SelectedEmotion();
            }
        }

        /* private void DataReceivedHandler(object sender, SerialDataReceivedEventArgs e)
        {
            SelectedEmotion();
        } */

        private string SelectedEmotion()
        {
            speech = new SpeechSynthesizer();
            EmotionList selectedEmotion;

            incomingMessage = "";
            try
            {
                incomingMessage = sp.ReadLine().Substring(14);
            }
            catch (Exception d)
            {
                //MessageBox.Show("No port");
                //incomingMessage = "NORMAL\r";
                //MessageBox.Show(d.Message + "4");
            }
          

            // ----------------
            // uncomment the following if you are using the MARY arduino script (still not working 100% for me)
            // ----------------

            //try
            //{
            //    // sp.Open();
            //    incomingMessage = myPort.ReadLine().Substring(14);
            //}
            //catch (Exception d)
            //{
            //    //MessageBox.Show("No port");
            //    incomingMessage = "NORMAL\r";
            //    //MessageBox.Show(d.Message+"4");
            //}

            // ----------------

            //incomingMessage = portName1.Substring(14);

            if (!Enum.TryParse(incomingMessage, true, out selectedEmotion))
            {
                selectedEmotion = EmotionList.normal;
            }

            if (incomingMessage == "\r\n")
            {
                incomingMessage = currentEmotion;
            }

            if (incomingMessage != currentEmotion)
            {
                switch (selectedEmotion)
                {
                    case EmotionList.happy:
                        {
                            //speech.Dispose();
                            //speech = new SpeechSynthesizer();
                            //speech.SpeakAsync("Happy");
                            //currentEmotion = incomingMessage;
                            currentEmotion = "HAPPY\r";
                            emotionChanged = true;
                            cEmotion = currentEmotion;
                            //notification.EmotionText.Text = cEmotion;
                            //notification.Show();
                            break;
                        }
                    case EmotionList.sad:
                        {
                            //speech.Dispose();
                            //speech = new SpeechSynthesizer();
                            //speech.SpeakAsync("Sad");
                            currentEmotion = "SAD\r";
                            emotionChanged = true;
                            cEmotion = currentEmotion;
                            //notification.EmotionText.Text = cEmotion;
                            //notification.Show();
                            break;
                        }
                    case EmotionList.angry:
                        {
                            //speech.Dispose();
                            //speech = new SpeechSynthesizer();
                            //speech.SpeakAsync("Angry");
                            currentEmotion = "ANGRY\r";
                            emotionChanged = true;
                            cEmotion = currentEmotion;
                            //notification.EmotionText.Text = cEmotion;
                            //notification.Show();
                            break;
                        }
                    case EmotionList.irritated:
                        {
                            //speech.Dispose();
                            //speech = new SpeechSynthesizer();
                            //speech.SpeakAsync("Irritated");
                            currentEmotion = "IRRITATED\r";
                            emotionChanged = true;
                            cEmotion = currentEmotion;
                            //notification.EmotionText.Text = cEmotion;
                            //notification.Show();
                            break;
                        }
                    case EmotionList.normal:
                        {
                            //speech.Dispose();
                            //speech = new SpeechSynthesizer();
                            //speech.SpeakAsync("Normal");
                            currentEmotion = "NORMAL\r";
                            emotionChanged = true;
                            cEmotion = currentEmotion;
                            //notification.EmotionText.Text = cEmotion;
                            //notification.Show();
                            break;
                        }
                    default:
                        {
                            //speech.Dispose();
                            //speech = new SpeechSynthesizer();
                            //speech.SpeakAsync("Normal");
                            currentEmotion = "NORMAL\r";
                            emotionChanged = true;
                            cEmotion = currentEmotion;
                            //notification.EmotionText.Text = cEmotion;
                            //notification.Show();
                            break;
                        }
                }

                return currentEmotion;
            }

            //Thread.CurrentThread.ApartmentState = ApartmentState.STA;
            //notification = new PopupNotification();

            //notification.EmotionText.Text = currentEmotion;
            //notification.Show();

            //Console.WriteLine(Thread.CurrentThread.Name.ToString());

            //EmotionText.Text = currentEmotion;
           
            //new Thread(() =>
            //{
            //    notification.EmotionText.Dispatcher.BeginInvoke((Action)(() => notification.EmotionText.Text = currentEmotion));
            //}).Start();

            //System.Windows.Application.Current.Dispatcher.Invoke((Action)delegate
            //{
            //    try
            //    {
            //        if (emotionChanged)
            //        {
            //            notification = new PopupNotification();
            //            notification.MainEmotionText.Text = "Selected Emotion : " + currentEmotion;
            //            notification.Show();
            //            notification.Focus();

            //            notification.Left = 0;
            //            //notification.Top = 700;
            //            notification.Top = System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Top;

            //            //notification.Close();
            //            emotionChanged = false;
            //            //notification.IsEnabled = false;


            //            //notification.Close();

            //            //if (notification.Opacity <= 0)
            //            //{
            //            //    notification.Close();
            //            //}
            //        }
            //        //notification.IsEnabled = true;
            //    }
            //    catch (Exception)
            //    {
            //        Thread.Sleep(1000);
            //    }
            //});
                
                return currentEmotion;
        }

        private void GetComPort()
        {
            int count = 0;
            availablePorts = null;
            arduinoPort = "";

            //List<string> strPort = new List<string>();
            //strPort.Add("hello");
            //strPort.RemoveRange(0, strPort.Count);
            while (count < 3)
            {
                availablePorts = SerialPort.GetPortNames();
                if (availablePorts.Length == 0)
                {
                    count++;
                }
                else
                {
                    count = 3;
                }

            }

            foreach (var item in availablePorts)
            {
                if (portList.IndexOf(item) < 0)
                {
                    portList.Add(item);
                }
            }

            foreach (string port in portList)
            {
                sp = new SerialPort(port);
                bool iState = sp.IsOpen;
                try
                {
                    if (portList.Count >= 0 && arduinoPort.Length == 0)// && count < 1)
                    {
                        sp.Open();
                        sp.DiscardOutBuffer();
                        sp.DiscardInBuffer();

                        portName1 = sp.ReadLine();
                        sp.DiscardInBuffer();


                        if (portName1.IndexOf("ArduinoSensor") >= 0)
                        {
                            arduinoPort = port;

                        }

                        sp.Close();
                    }
                }
                catch (Exception e)
                {
                    //portName1 = sp.ReadLine();
                    portName1 = "Port busy";
                    sp.Close();
                    MessageBox.Show(e.Message + "3");
                }
            }

            if (arduinoPort.Length > 0)
            {
                sp = new SerialPort(arduinoPort);
                sp.Open();
                MessageFromArduino();
            }
            else
            {
                MessageBox.Show("No Arduino port found");
            }

        }

        private void DeviceInsertedEvent(object sender, EventArrivedEventArgs e)
        {
            //this.getPortThread = new Thread(new ThreadStart(this.GetComPort));
            //this.getPortThread.Start();
            //Thread.Sleep(100);

            //if (getPortThread.ThreadState.ToString() == "Aborted")
            //{
            //    this.getPortThread = new Thread(new ThreadStart(this.GetComPort));
            //    this.getPortThread.Start();
            //}

            currentEmotion = "";
            ManagementBaseObject instance = (ManagementBaseObject)e.NewEvent["TargetInstance"];
            //foreach (var property in instance.Properties)
            //{
            //GetComPort();

            try
            {
                //if (sp != null && !sp.IsOpen)
                //{
                //    sp.Open();
                //}

                //if (availablePorts.Length == 0)
                //{
                //    GetComPort();
                //}

                string state = this.getPortThread.ThreadState.ToString();
                if (state == "Aborted" || state == "Stopped")
                {
                    this.getPortThread = new Thread(new ThreadStart(this.GetComPort));
                    this.getPortThread.Start();
                }

                //MessageFromArduino();
            }
            catch (Exception a)
            {
                MessageBox.Show(a.Message + "4");
            }


            //}
        }

        void DeviceRemovedEvent(object sender, EventArrivedEventArgs e)
        {
            ManagementBaseObject instance = (ManagementBaseObject)e.NewEvent["TargetInstance"];
            // foreach (var property in instance.Properties)
            //{
            //Close the port that was unplugged --------------------------------------------------------------------------------------------------------------------------------------
            try
            {
                int num = 0;
                foreach (var item in availablePorts)
                {
                    availablePorts[num] = "";
                    num++;
                }

                portList.RemoveRange(0, portList.Count);
                // availablePorts = null;
                sp.Close();
                getPortThread.Abort();
                //this.getPortThread.Abort();

            }
            catch (Exception b)
            {
                MessageBox.Show(b.Message + "1");
            }
            //sp.Open();
            //Write property.Name and property.Value
            //getPortThread.Abort();
            //}
        }

        private void BackgroundWorker_DoWork(object sender, DoWorkEventArgs e)
        {

            //WqlEventQuery insertQuery = new WqlEventQuery("SELECT * FROM __InstanceCreationEvent WITHIN 2 WHERE TargetInstance ISA 'Win32_USBHub'");
            WqlEventQuery insertQuery = new WqlEventQuery("SELECT * FROM __InstanceCreationEvent WITHIN 2 WHERE TargetInstance ISA 'Win32_SerialPort'");

            ManagementEventWatcher insertWatcher = new ManagementEventWatcher(insertQuery);
            insertWatcher.EventArrived += new EventArrivedEventHandler(DeviceInsertedEvent);
            insertWatcher.Start();

            WqlEventQuery removeQuery = new WqlEventQuery("SELECT * FROM __InstanceDeletionEvent WITHIN 2 WHERE TargetInstance ISA 'Win32_SerialPort'");
            ManagementEventWatcher removeWatcher = new ManagementEventWatcher(removeQuery);
            removeWatcher.EventArrived += new EventArrivedEventHandler(DeviceRemovedEvent);
            removeWatcher.Start();

            // Do something while waiting for events

            Thread.Sleep(500);
        }

        private void ThreadNotify() 
        {
            while (true)
            {
                try
                {
                    if (emotionChanged)
                    {
                        notification = new PopupNotification();
                        notification.MainEmotionText.Text = "Selected Emotion : " + currentEmotion;
                        notification.Show();
                        
                        notification.Focus();

                        notification.Left = 0;
                       // notification.Top = 700;
                        notification.Top = System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Top;

                        //notification.Close();
                        emotionChanged = false;
                        //notification.IsEnabled = false;
                        Thread.Sleep(5000);
                        notification.Close();

                        //notification.Close();

                        //if (notification.Opacity <= 0)
                        //{
                        //    notification.Close();
                        //}
                    }
                    //notification.IsEnabled = true;
                }
                catch (Exception)
                {
                    Thread.Sleep(1000);
                }
            }
        }

        #endregion


    }
}
