﻿using JuliusSweetland.OptiKey.UI.Controls;

namespace JuliusSweetland.OptiKey.UI.Views.Keyboards.French
{
    /// <summary>
    /// Interaction logic for Diacritics3.xaml
    /// </summary>
    public partial class Diacritics3 : KeyboardView
    {
        public Diacritics3() : base(shiftAware: true)
        {
            InitializeComponent();
        }
    }
}
