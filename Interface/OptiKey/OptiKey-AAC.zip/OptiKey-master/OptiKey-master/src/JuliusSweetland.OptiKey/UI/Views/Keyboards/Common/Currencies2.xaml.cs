﻿using JuliusSweetland.OptiKey.UI.Controls;

namespace JuliusSweetland.OptiKey.UI.Views.Keyboards.Common
{
    /// <summary>
    /// Interaction logic for Currencies2.xaml
    /// </summary>
    public partial class Currencies2 : KeyboardView
    {
        public Currencies2()
        {
            InitializeComponent();
        }
    }
}
