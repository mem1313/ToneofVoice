﻿namespace JuliusSweetland.OptiKey.Native.Enums
{
    public enum AppBarNotify : uint
    {
        StateChange= 0,
        PositionChanged,
        FullScreenApp,
        WindowArrange
    }
}
