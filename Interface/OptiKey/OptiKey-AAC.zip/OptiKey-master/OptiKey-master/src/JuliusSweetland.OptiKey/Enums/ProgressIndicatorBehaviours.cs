﻿namespace JuliusSweetland.OptiKey.Enums
{
    public enum ProgressIndicatorBehaviours
    {
        FillPie,
        Shrink,
        Grow
    }
}            
