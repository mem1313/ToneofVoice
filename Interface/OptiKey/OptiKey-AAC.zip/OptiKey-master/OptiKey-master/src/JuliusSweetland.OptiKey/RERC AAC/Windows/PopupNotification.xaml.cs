﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;
using System.Windows.Forms;
using System.ComponentModel;

namespace JuliusSweetland.OptiKey.RERC_AAC.Windows
{
    /// <summary>
    /// Interaction logic for PopupNotification.xaml
    /// </summary>
    public partial class PopupNotification : Window, INotifyPropertyChanged
    {
        public PopupNotification()
        {
            //displayEmotion = "TEST Emotion";
            InitializeComponent();

            /*Dispatcher.BeginInvoke(DispatcherPriority.ApplicationIdle, new Action(() =>
                {
                    var workingArea = Screen.PrimaryScreen.WorkingArea;
                    var transform = PresentationSource.FromVisual(this).CompositionTarget.TransformFromDevice;
                    var corner = transform.Transform(new Point(workingArea.Right, workingArea.Bottom));

                    this.Left = corner.X - this.ActualWidth - 100;
                    this.Top = corner.Y - this.ActualHeight;
                }));*/
            DataContext = this;

            
        }

        private string displayEmotion;

        public event PropertyChangedEventHandler PropertyChanged;

        private void OnPropertyChanged(string emotion)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(emotion));
            }
        }

        public string DisplayEmotion
        {
            get { return displayEmotion; }
            set
            {
                displayEmotion = value;
                OnPropertyChanged(value);
            }
        }

        private void Border_IsEnabledChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if(this.Opacity <= 0)
            {
                this.Close();
            }
        }
    }
}
