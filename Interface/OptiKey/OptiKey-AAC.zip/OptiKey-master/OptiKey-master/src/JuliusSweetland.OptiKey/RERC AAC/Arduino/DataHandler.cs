﻿using System;
using System.IO.Ports;
using System.Threading;
using System.Speech.Synthesis;
using JuliusSweetland.OptiKey.RERC_AAC.Enums;
using JuliusSweetland.OptiKey.RERC_AAC.Windows;
using JuliusSweetland.OptiKey.UI.Windows;

namespace JuliusSweetland.OptiKey.RERC_AAC.Arduino
{
    class DataHandler
    {

        #region Fields
        static private SerialPort myPort;
        private string incomingMessage;
        private SpeechSynthesizer speech;
        private string currentEmotion;
        private static string cEmotion;
        delegate void setArduinoMessage(string text);
        private Thread arduinoMessageThread;
        private PopupNotification notification;
        private bool emotionChanged;
        #endregion

        #region Methods
        public DataHandler()
        {
            myPort = new SerialPort();
            currentEmotion = string.Empty;
            arduinoMessageThread = null;
            cEmotion = string.Empty;
            emotionChanged = false;

            //arduinoMessageThread = new Thread(new ThreadStart(this.MessageFromArduino));
            //arduinoMessageThread.SetApartmentState(ApartmentState.STA);
            //arduinoMessageThread.Start();

            MessageFromArduino();
        }

        private void MessageFromArduino()
        {
            //notification = new PopupNotification();
            myPort.PortName = "COM5";
            myPort.BaudRate = 9600;
            myPort.Parity = Parity.None;
            myPort.StopBits = StopBits.One;
            myPort.DataBits = 8;
            myPort.Handshake = Handshake.None;
            myPort.RtsEnable = true;

            // using an event instead of a thread
            // this is for testing purposes and it works 
            myPort.DataReceived += new SerialDataReceivedEventHandler(DataReceivedHandler);

            myPort.Open();

            //while (myPort.IsOpen)
            //{
            //    cEmotion = SelectedEmotion();

            //    if(emotionChanged)
            //    {
            //        notification.EmotionText.Text = cEmotion;
            //        notification.Show();
            //        emotionChanged = false;
            //    }
                
            //}
        }

        private void DataReceivedHandler(object sender, SerialDataReceivedEventArgs e)
        {
            SelectedEmotion();
        }

        private string SelectedEmotion()
        {
            speech = new SpeechSynthesizer();
            EmotionList selectedEmotion;
            
            incomingMessage = myPort.ReadLine();

            // ----------------
            // uncomment the following if you are using the MARY arduino script (still not working 100% for me)
            // ----------------

            //try
            //{
            //    // sp.Open();
            //    incomingMessage = myPort.ReadLine().Substring(14);
            //}
            //catch (Exception d)
            //{
            //    //MessageBox.Show("No port");
            //    incomingMessage = "NORMAL\r";
            //    //MessageBox.Show(d.Message+"4");
            //}

            // ----------------



            if (!Enum.TryParse(incomingMessage, true, out selectedEmotion))
            {
                selectedEmotion = EmotionList.normal;
            }

            if (incomingMessage == "\r\n")
            {
                incomingMessage = currentEmotion;
            }

            if (incomingMessage != currentEmotion)
            {
                switch (selectedEmotion)
                {
                    case EmotionList.happy:
                        {
                            //speech.Dispose();
                            //speech = new SpeechSynthesizer();
                            //speech.SpeakAsync("Happy");
                            currentEmotion = incomingMessage;
                            emotionChanged = true;
                            cEmotion = currentEmotion;
                            currentEmotion = "HAPPY\r";
                            //notification.EmotionText.Text = cEmotion;
                            //notification.Show();
                            break;
                        }
                    case EmotionList.sad:
                        {
                            //speech.Dispose();
                            //speech = new SpeechSynthesizer();
                            //speech.SpeakAsync("Sad");
                            currentEmotion = incomingMessage;
                            emotionChanged = true;
                            cEmotion = currentEmotion;
                            currentEmotion = "SAD\r";
                            //notification.EmotionText.Text = cEmotion;
                            //notification.Show();
                            break;
                        }
                    case EmotionList.angry:
                        {
                            //speech.Dispose();
                            //speech = new SpeechSynthesizer();
                            //speech.SpeakAsync("Angry");
                            currentEmotion = incomingMessage;
                            emotionChanged = true;
                            cEmotion = currentEmotion;
                            currentEmotion = "ANGRY\r";
                            //notification.EmotionText.Text = cEmotion;
                            //notification.Show();
                            break;
                        }
                    case EmotionList.irritated:
                        {
                            //speech.Dispose();
                            //speech = new SpeechSynthesizer();
                            //speech.SpeakAsync("Irritated");
                            currentEmotion = incomingMessage;
                            emotionChanged = true;
                            cEmotion = currentEmotion;
                            currentEmotion = "IRRITATED\r";
                            //notification.EmotionText.Text = cEmotion;
                            //notification.Show();
                            break;
                        }
                    case EmotionList.normal:
                        {
                            //speech.Dispose();
                            //speech = new SpeechSynthesizer();
                            //speech.SpeakAsync("Normal");
                            currentEmotion = incomingMessage;
                            emotionChanged = true;
                            cEmotion = currentEmotion;
                            currentEmotion = "NORMAL\r";
                            //notification.EmotionText.Text = cEmotion;
                            //notification.Show();
                            break;
                        }
                    default:
                        {
                            //speech.Dispose();
                            //speech = new SpeechSynthesizer();
                            //speech.SpeakAsync("Normal");
                            currentEmotion = incomingMessage;
                            emotionChanged = true;
                            cEmotion = currentEmotion;
                            currentEmotion = "NORMAL\r";
                            //notification.EmotionText.Text = cEmotion;
                            //notification.Show();
                            break;
                        }
                }
            }

            //Thread.CurrentThread.ApartmentState = ApartmentState.STA;
            //notification = new PopupNotification();

            //notification.EmotionText.Text = currentEmotion;
            //notification.Show();

            //Console.WriteLine(Thread.CurrentThread.Name.ToString());

            //EmotionText.Text = currentEmotion;

            //new Thread(() =>
            //{
            //    notification.EmotionText.Dispatcher.BeginInvoke((Action)(() => notification.EmotionText.Text = currentEmotion));
            //    notification.Show();
            //}).Start();

            System.Windows.Application.Current.Dispatcher.Invoke((Action)delegate
            {
                if (emotionChanged)
                {
                    notification = new PopupNotification();
                    notification.MainEmotionText.Text = "Selected Emotion : " + currentEmotion;                    
                    notification.Show();
                    notification.Focus();

                    notification.Left = 0;
                    //notification.Top = 700;
                    notification.Top = System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Top;           
                    
                    //notification.Close();
                    emotionChanged = false;
                    //notification.IsEnabled = false;
                   

                    //notification.Close();

                    //if (notification.Opacity <= 0)
                    //{
                    //    notification.Close();
                    //}
                }
                //notification.IsEnabled = true;
                 
            });

            return currentEmotion;
        }
        #endregion

        #region Properties 
        public static string Emotion
        {
            get { return cEmotion; }
            //set { cEmotion = value; }
        }

        #endregion
    }
}
