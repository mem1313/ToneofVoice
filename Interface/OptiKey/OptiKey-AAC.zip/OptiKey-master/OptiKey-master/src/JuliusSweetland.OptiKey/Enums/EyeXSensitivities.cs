namespace JuliusSweetland.OptiKey.Enums
{
    public enum EyeXSensitivities
    {
        Low,
        Medium,
        High,
        VeryHigh
    }
}
