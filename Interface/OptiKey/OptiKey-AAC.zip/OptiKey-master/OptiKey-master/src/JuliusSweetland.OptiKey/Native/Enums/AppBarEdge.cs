﻿namespace JuliusSweetland.OptiKey.Native.Enums
{
    public enum AppBarEdge : uint
    {
        Left = 0,
        Top = 1,
        Right = 2,
        Bottom = 3
    }
}
