﻿namespace JuliusSweetland.OptiKey.Enums
{
    public enum TaskbarPosition
    {
        Unknown = -1,
        Left,
        Top,
        Right,
        Bottom,
    }
}
