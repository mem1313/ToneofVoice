﻿namespace JuliusSweetland.OptiKey.UI.ViewModels.Keyboards.Base
{
    public interface IConversationKeyboard
    {
    }
}
