﻿namespace JuliusSweetland.OptiKey.Enums
{
    public enum FontStretches
    {
        UltraCondensed,
        ExtraCondensed,
        Condensed,
        SemiCondensed,
        Medium,
        Normal,
        SemiExpanded,
        Expanded,
        ExtraExpanded,
        UltraExpanded
    }
}
