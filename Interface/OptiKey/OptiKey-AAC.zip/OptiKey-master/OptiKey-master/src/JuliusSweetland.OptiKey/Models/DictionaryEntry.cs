﻿namespace JuliusSweetland.OptiKey.Models
{
    public class DictionaryEntry
    {
        public string Entry { get; set; }
        public int UsageCount { get; set; }
    }
}
