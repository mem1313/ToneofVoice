namespace JuliusSweetland.OptiKey.Enums
{
    public enum MinimisedEdges
    {
        SameAsDockedPosition,
        Top,
        Left,
        Bottom,
        Right
    }
}
