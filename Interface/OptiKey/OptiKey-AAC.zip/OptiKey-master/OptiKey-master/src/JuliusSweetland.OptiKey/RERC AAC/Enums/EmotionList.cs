﻿namespace JuliusSweetland.OptiKey.RERC_AAC.Enums
{
    public enum EmotionList
    {
        #region old emotions
        //happy,
        //sad,
        //angry,
        //// The following can be replaced with appropriate emotions
        //normal1,
        //normal2,
        //normal3,
        //normal4
        #endregion

        happy,
        sad,
        angry,
        irritated,
        normal 
    }
}
