namespace JuliusSweetland.OptiKey.Enums
{
    public enum WindowStates
    {
        Docked,
        Floating,
        Hidden,
        Maximised,
        Minimised
    }
}
