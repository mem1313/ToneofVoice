﻿using System.Windows.Controls;

namespace JuliusSweetland.OptiKey.UI.Controls
{
    public class ToastNotification : UserControl
    {
    }
}
