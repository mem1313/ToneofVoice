﻿namespace JuliusSweetland.OptiKey.Enums
{
    public enum CursorPointPositions
    {
        ToTopLeft,
        ToTopRight,
        ToBottomLeft,
        ToBottomRight
    }
}
