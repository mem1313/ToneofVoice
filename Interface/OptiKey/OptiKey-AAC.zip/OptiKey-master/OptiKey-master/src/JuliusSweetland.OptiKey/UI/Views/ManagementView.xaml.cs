﻿using System.Windows.Controls;

namespace JuliusSweetland.OptiKey.UI.Views
{
    /// <summary>
    /// Interaction logic for ManagementView.xaml
    /// </summary>
    public partial class ManagementView : UserControl
    {
        public ManagementView()
        {
            InitializeComponent();
        }
    }
}
