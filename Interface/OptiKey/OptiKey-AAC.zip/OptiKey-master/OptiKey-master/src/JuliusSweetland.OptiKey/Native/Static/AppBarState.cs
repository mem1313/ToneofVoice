﻿namespace JuliusSweetland.OptiKey.Native.Static
{
    public static class AppBarState
    {
        public const int Autohide = 0x0000001;
        public const int AlwaysOnTop = 0x0000002;
    }
}
