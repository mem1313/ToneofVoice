
Use "NBug.Configurator.exe" file to configure the bug report submitter.
Use "NBug.TestApp.exe" to test your configuration. You should see an Exception_***.zip file generated after a test crash.

For documentation and updates, see project web site: http://www.soygul.com/projects/nbug/

For bug reports, you can use the issue tracker: https://github.com/soygul/NBug/issues

� 2013, Teoman Soygul