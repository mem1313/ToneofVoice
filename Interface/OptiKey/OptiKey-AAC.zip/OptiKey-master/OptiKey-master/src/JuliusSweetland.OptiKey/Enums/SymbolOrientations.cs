namespace JuliusSweetland.OptiKey.Enums
{
    public enum SymbolOrientations
    {
        Top,
        Left,
        Bottom,
        Right
    }
}
