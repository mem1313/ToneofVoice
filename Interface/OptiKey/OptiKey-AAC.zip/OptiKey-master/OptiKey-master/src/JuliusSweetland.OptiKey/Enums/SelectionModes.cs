﻿namespace JuliusSweetland.OptiKey.Enums
{
    public enum SelectionModes
    {
        Key,
        Point
    }
}
