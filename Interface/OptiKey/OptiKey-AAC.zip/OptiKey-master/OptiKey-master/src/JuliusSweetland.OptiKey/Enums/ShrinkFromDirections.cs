namespace JuliusSweetland.OptiKey.Enums
{
    public enum ShrinkFromDirections
    {
        TopLeft,
        Top,
        TopRight,
        Right,
        BottomRight,
        Bottom,
        BottomLeft,
        Left
    }
}
