﻿using System;

namespace JuliusSweetland.OptiKey.UI.ViewModels.Keyboards.Base
{
    public interface IBackAction
    {
        Action BackAction { get; }
    }
}